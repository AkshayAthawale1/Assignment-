package BackendApi;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Student")
public class StudentModel {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sid;

	@Column(name = "Student_Name")
	private String name;

	@Column(name = "Student_Lastname")
	private String lastname;

	@Column(name = "Student_Age")
	private String age;

	@Column(name = "Phone_Number")
	private String number;

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}


	
	public StudentModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentModel(int sid, String name, String lastname, String age, String number) {
		super();
		this.sid = sid;
		this.name = name;
		this.lastname = lastname;
		this.age = age;
		this.number = number;
	}

	@Override
	public String toString() {
		return "ProductsModel [sid=" + sid + ", name=" + name + ", lastname=" + lastname + ", age=" + age + ", number="
				+ number + "]";
	}

}
