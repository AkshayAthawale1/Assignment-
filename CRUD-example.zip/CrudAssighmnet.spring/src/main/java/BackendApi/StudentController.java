package BackendApi;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {

	@Autowired
	StudentService service;

	@GetMapping("getAllStudent")
	public List<StudentModel> findAllProducts() {
		return service.listOfStudents();
	}

	@GetMapping("getOneStudent/{id}")
	public Optional<StudentModel> getOneStudent(@PathVariable Integer id) {
		return service.getOneStudent(id);
	}

	@PostMapping("addStudent")
	public void addStudent(@RequestBody StudentModel studentModel) {
		service.addStudent(studentModel);
	}

	@PutMapping("update")
	public void updateStudent(@RequestBody StudentModel studentModel) {
		service.updateStudent(studentModel);
	}

	@DeleteMapping("delete/{id}")
	public void deleteOneStudent(@PathVariable Integer id) {
		service.deleteOneStudent(id);
	}
}
